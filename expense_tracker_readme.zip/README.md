
# Expense Tracker Web App – Flask + SQLite

A fully functional and responsive Expense Tracker web application built using **Flask**, **Bootstrap**, and **SQLite**. This app helps users efficiently manage their daily expenses, track monthly spending, and gain insights into personal finance habits.

## 🚀 Features

- 🔐 User Authentication (Login/Logout)
- 📅 Add/Edit/Delete Daily Expenses
- 📊 Monthly Expense Summary with Analytics
- 💾 Data stored securely using SQLite
- 🌐 Deployed on Render for live preview
- 🎨 Clean and responsive UI with Bootstrap

## 🛠️ Tech Stack

- **Backend**: Python, Flask
- **Frontend**: HTML5, CSS3, Bootstrap 5
- **Database**: SQLite
- **Deployment**: Render
- **Version Control**: Git & GitHub

## 📸 Screenshots

_Coming Soon_ (you can add your app screenshots here)

## 📁 Project Structure

```
expense-tracker-flask/
│
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── templates/              # HTML files (Jinja templates)
│   ├── index.html
│   ├── login.html
│   └── dashboard.html
└── static/                 # CSS and other assets
```

## 📦 Installation Guide

1. Clone the repository:

```bash
git clone https://github.com/Amarjeet2131/expense-tracker-flask.git
cd expense-tracker-flask
```

2. Create virtual environment and activate it:

```bash
python -m venv venv
source venv/bin/activate  # For Windows use: venv\Scripts\activate
```

3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run the app:

```bash
python app.py
```

Open your browser and go to http://127.0.0.1:5000

## 🌍 Live Demo

🔗 Live App on Render (replace with actual link)

## 🤝 Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## 📧 Contact

**Amarjeet Kushwaha**  
📧 asaneamarjit@gmail.com  
🌐 [LinkedIn](https://www.linkedin.com/in/amarjeet-kushwaha-05131a297)  
💻 [GitHub](https://github.com/Amarjeet2131)

---

⭐ If you like this project, don’t forget to give it a star on GitHub!
