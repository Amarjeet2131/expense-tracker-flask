# Expense Tracker Web App

A simple Flask-based web app for tracking daily expenses.
